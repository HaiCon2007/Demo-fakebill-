-- MariaDB dump 10.19  Distrib 10.5.22-MariaDB, for Linux (x86_64)
--
-- Host: sql107.byetcluster.com    Database: if0_38420386_shophaicon
-- ------------------------------------------------------
-- Server version	10.6.19-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `accounts`
--

DROP TABLE IF EXISTS `accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `accounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `age` int(11) DEFAULT NULL,
  `height` decimal(5,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accounts`
--

LOCK TABLES `accounts` WRITE;
/*!40000 ALTER TABLE `accounts` DISABLE KEYS */;
INSERT INTO `accounts` VALUES (1,'admin','hashedpassword',25,1.75);
/*!40000 ALTER TABLE `accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bank1`
--

DROP TABLE IF EXISTS `bank1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bank1` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `active` int(1) DEFAULT 1,
  `onlyAdmin` int(1) DEFAULT 0,
  `bdsd` tinyint(1) NOT NULL DEFAULT 1,
  `sodu` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bank1`
--

LOCK TABLES `bank1` WRITE;
/*!40000 ALTER TABLE `bank1` DISABLE KEYS */;
INSERT INTO `bank1` VALUES (1,'momo','momo',1,0,1,1),(2,'vietinbank','vietinbank',1,0,1,1),(3,'vpbank','vpbank',1,0,1,1),(5,'bidv','bidv',1,0,1,1),(6,'acb','acb',1,0,1,1),(7,'agribank','agribank',1,0,1,1),(8,'techcombank_vip','techcombank_vip',1,0,1,1),(12,'tpbank','tpbank',1,0,1,1),(13,'vietcombank','vietcombank',1,0,1,1),(15,'mbbank','mbbank',1,0,1,1);
/*!40000 ALTER TABLE `bank1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bdsd`
--

DROP TABLE IF EXISTS `bdsd`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bdsd` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `active` int(1) DEFAULT 1,
  `onlyAdmin` int(1) DEFAULT 0,
  `bdsd` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bdsd`
--

LOCK TABLES `bdsd` WRITE;
/*!40000 ALTER TABLE `bdsd` DISABLE KEYS */;
INSERT INTO `bdsd` VALUES (1,'vietcombank','vietcombank',1,0,1),(2,'acb','acb',1,0,1),(3,'mbbank','mbbank',1,0,1);
/*!40000 ALTER TABLE `bdsd` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contact_info`
--

DROP TABLE IF EXISTS `contact_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contact_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `facebook_link` varchar(255) DEFAULT NULL,
  `zalo_link` varchar(255) DEFAULT NULL,
  `telegram_link` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contact_info`
--

LOCK TABLES `contact_info` WRITE;
/*!40000 ALTER TABLE `contact_info` DISABLE KEYS */;
INSERT INTO `contact_info` VALUES (1,'https://www.facebook.com/share/12Eu1DjoorR/','https://zalo.me/0852337392','https://t.me/haiconz2007');
/*!40000 ALTER TABLE `contact_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fakesodu`
--

DROP TABLE IF EXISTS `fakesodu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fakesodu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `active` int(1) DEFAULT 1,
  `onlyAdmin` int(1) DEFAULT 0,
  `bdsd` tinyint(1) NOT NULL DEFAULT 1,
  `sodu` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fakesodu`
--

LOCK TABLES `fakesodu` WRITE;
/*!40000 ALTER TABLE `fakesodu` DISABLE KEYS */;
INSERT INTO `fakesodu` VALUES (6,'bidv','bidv',1,0,1,1),(17,'mbbank','mbbank',1,0,1,1),(13,'vietcombank','vietcombank',1,0,1,1),(15,'vietinbank','vietinbank',1,0,1,1);
/*!40000 ALTER TABLE `fakesodu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `history_bill`
--

DROP TABLE IF EXISTS `history_bill`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `history_bill` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bank` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `time_create` datetime NOT NULL,
  `for_username` varchar(255) NOT NULL,
  `image_url` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `history_bill`
--

LOCK TABLES `history_bill` WRITE;
/*!40000 ALTER TABLE `history_bill` DISABLE KEYS */;
/*!40000 ALTER TABLE `history_bill` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `notifications` mediumtext NOT NULL,
  `amount` decimal(20,2) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=504 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
INSERT INTO `notifications` VALUES (503,'haihi','Đã tạo 1 bill Tech, số tiền trừ 5000',5000.00,'2025-03-25 12:43:09'),(498,'haihi','Đã tạo 1 bill MOMO, số tiền trừ 5000',5000.00,'2025-03-25 12:41:48'),(499,'haihi','Đã tạo 1 bill VP, số tiền trừ 5000',5000.00,'2025-03-25 12:42:12'),(500,'haihi','Đã tạo 1 bill BIDV, số tiền trừ 5000',5000.00,'2025-03-25 12:42:24'),(501,'haihi','Đã tạo 1 bill ACB, số tiền trừ 5000',5000.00,'2025-03-25 12:42:35'),(502,'haihi','Đã tạo 1 bill Agribank, số tiền trừ 5000',5000.00,'2025-03-25 12:42:58'),(496,'admin','Đã tạo 1 bill TP, số tiền trừ 5000',5000.00,'2025-03-25 11:22:12'),(497,'admin','Đã tạo 1 bill Vietcombank, số tiền trừ 5000',5000.00,'2025-03-25 11:26:47'),(495,'admin','Đã tạo 1 bill BIDV, số tiền trừ 5000',5000.00,'2025-03-25 11:18:11'),(491,'Quan2004','Đã tạo 1 cccd, số tiền trừ 5000',5000.00,'2025-03-25 06:55:06'),(492,'Khang','Đã tạo 1 cccd, số tiền trừ 5000',5000.00,'2025-03-25 09:18:01'),(493,'admin','Đã tạo 1 bill BIDV, số tiền trừ 5000',5000.00,'2025-03-25 11:14:14'),(494,'admin','Đã tạo 1 bill BIDV, số tiền trừ 5000',5000.00,'2025-03-25 11:16:39'),(490,'Nguyenknnthu67_','Đã tạo 1 bill Agribank, số tiền trừ 5000',5000.00,'2025-03-25 04:55:58'),(489,'Nguyenknnthu67_','Đã tạo 1 bill Agribank, số tiền trừ 5000',5000.00,'2025-03-25 04:49:01'),(488,'Nguyenknnthu67_','Đã tạo 1 bill Agribank, số tiền trừ 5000',5000.00,'2025-03-25 04:48:12');
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `profile`
--

DROP TABLE IF EXISTS `profile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `profile` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `signature` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `profile`
--

LOCK TABLES `profile` WRITE;
/*!40000 ALTER TABLE `profile` DISABLE KEYS */;
INSERT INTO `profile` VALUES (1,1,'Admin của hệ thống');
/*!40000 ALTER TABLE `profile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `settings` (
  `id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `banner` varchar(255) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `luottaobill` int(11) DEFAULT 0,
  `fakebillfree` int(11) DEFAULT 0,
  `luottaocccd` int(11) DEFAULT 0,
  `luottaohochieu` int(11) DEFAULT 0,
  `tongtiengoc` int(11) NOT NULL DEFAULT 50000,
  `tiengoc` int(11) DEFAULT 5000
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES (1,'Dịch Vụ Fakebill ','Tất cả bill đã hoạt động bình thường,  chúc mọi người sử dụng vui vẻ ????????','https://shophaicon.wuaze.com/banner123.png',0.00,2410,0,829,642,5000,5000);
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transactions`
--

DROP TABLE IF EXISTS `transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transactions` (
  `id` int(11) NOT NULL,
  `transaction_id` varchar(255) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `amount` decimal(20,2) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `transaction_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `transaction_type` enum('deposit','withdrawal','transfer') NOT NULL,
  `notifications` text DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transactions`
--

LOCK TABLES `transactions` WRITE;
/*!40000 ALTER TABLE `transactions` DISABLE KEYS */;
INSERT INTO `transactions` VALUES (1,'TX123456',1,50000.00,'Nạp tiền vào tài khoản','2025-03-18 23:53:15','deposit',NULL);
/*!40000 ALTER TABLE `transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `VIP` int(11) DEFAULT 0,
  `sodu` decimal(10,2) DEFAULT 0.00,
  `avatar` varchar(255) DEFAULT '',
  `tichxanh` int(11) DEFAULT 0,
  `billck` int(11) DEFAULT 0,
  `date_bill` date DEFAULT NULL,
  `serial_key` varchar(255) NOT NULL,
  `tongtiennap` decimal(10,2) DEFAULT 0.00,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (18,'admin','$2y$10$ffOiBkPgLF42KjJw9mDFMeI7ZCp3Ca9tJ1wH2xMpEziKqht0Vxwv.',0,99459999.99,'',0,0,'2025-03-25','52NL1M66HTDC6WE',99999999.99,'2025-03-22 12:44:51'),(38,'Dvmxh09','$2y$10$qB9NWdRr655ncQRwSmbY6ucRGWjCvn5y53Rj/VIU.xREAJ9J/EO3W',0,99999999.99,'',0,0,'2025-03-25','EIVA35CLQRHV61C',0.00,'2025-03-25 13:41:36'),(37,'haihi','$2y$10$.mvBh2ycKjG/NHNEpoSbfOpTuU02rIdzuhwfNczL8xcub/1Wox6IW',0,99969999.99,'',0,0,'2025-03-25','XCY0D1IMHQ2EXYI',0.00,'2025-03-25 12:41:23'),(36,'Khang','$2y$10$e10TtdmCY8Hj/FRgrKeEMuReFW99JPEIsOaC/RFC16FCvXyYXf06a',0,99994999.99,'',0,0,'2025-03-25','U3H4RSM8FUICVO9',0.00,'2025-03-25 09:16:00'),(35,'Quan2004','$2y$10$GWf56wTCkdG3kUokP355xO5j4SxiEYY6bMvL6JBPZXiveQDga3oMK',0,99994999.99,'',0,0,'2025-03-25','5RQCXPKCZ8WB33J',0.00,'2025-03-25 06:54:37'),(34,'Quan1109','$2y$10$jnLUCKCSG.RqB8J/a4DUie2Z8DZOM6g7DDBwQ/wG91nH/WlM5DDta',0,99999999.99,'',0,0,'2025-03-25','VPFKN9D5VPK5JFI',0.00,'2025-03-25 06:52:58'),(33,'Nguyenknnthu67_','$2y$10$i0YWtTZVbvOTPdIJwZjqEuRLkplMHoFT9ySlokupqeZS4xk1od9x2',0,99984999.99,'',0,0,'2025-03-25','DEAVK00Y7E0OUDJ',0.00,'2025-03-25 04:45:24'),(32,'Bsgmstmsnzgn','$2y$10$kHzSDndW/DYIJyGky1jUneu9y37gX2vS2IcAKfWZZGiJuny3NO/R.',0,99999999.99,'',0,0,'2025-03-25','QJ601U1G3S2NSIR',0.00,'2025-03-24 17:46:57'),(31,'Hwjstjtjwh','$2y$10$2eUf7whDqDTw2yl/wXCx8OuOXTbt/r./rJlPwSJu27Z6NMLLRWYpy',0,99874999.99,'',0,0,'2025-03-25','FVZP790X2CPRCQE',0.00,'2025-03-24 17:45:57'),(30,'vietnam','$2y$10$gHDkM.anG3w6tceieku7k.bS3MgTgJN45JSlyQOaBv3ZcEwHG6qcW',0,99999999.99,'',0,0,'2025-03-25','T25K0ANUGFKP53R',0.00,'2025-03-24 17:45:23'),(29,'hihi','$2y$10$54T4j6ervtp3G8TeYtWiWemszMdo4W35IkJg5UhVxDVc43/tHHta.',0,99999999.99,'',0,0,'2025-03-25','OZM85803O6RJ0L7',0.00,'2025-03-24 17:45:09'),(28,'dungthu','$2y$10$bQDrQb.kjs/cZrKFReL43OVy9bXOtV3g6J/.AQTeODHAFu/DxilAe',0,99999999.99,'',0,0,'2025-03-25','1YLM55OMI1TSY8N',0.00,'2025-03-24 17:44:58'),(27,'Hungdzyc','$2y$10$gG87A6goIkP7LozFohsLg.4f9yYf6kywG5.tvZPblllg2.rVGatxq',0,99999999.99,'',0,0,'2025-03-24','DCA7DD4B7XY7KWC',0.00,'2025-03-24 15:59:54');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-03-26 10:45:23
